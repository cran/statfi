library(devtools)
document("../../")

library(knitr)
knit("../../vignettes/statfi_tutorial.Rmd", "../../vignettes/statfi_tutorial.md")



