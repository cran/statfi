Todo datasets for statfi packages
-------------------

* [Inspire-data](http://www.tilastokeskus.fi/tup/rajapintapalvelut/inspire_aineistot.html)